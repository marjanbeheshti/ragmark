#!/usr/bin/env python3
"""
Text-Binding Extension vs Payload-Swap (Walkthrough Sec. 8)
===========================================================
The separation assumption (vector index and document store are distinct
trust boundaries) does real work in the paper: it is why a payload-swap
attack -- keep a validly watermarked vector, change the TEXT it
dereferences -- is declared out of scope. This experiment converts the
"one-line fix we note but do not require" into a measured defense, so
the assumption can be softened rather than load-bearing.

The extension: bind h_text = H(passage_text) into the signed tuple.
At verification the gate recomputes H(text) of the dereferenced passage
and compares. A co-located adversary who swaps the text (without the
key) cannot produce a matching h_text, so the swap is rejected.

  (A) No text-binding (base): payload-swap passes -- the vector still
      verifies, and nothing checks the text. (The out-of-scope case.)
  (B) With text-binding: the same swap is rejected (h_text mismatch),
      while legitimate (vector, text) pairs pass.
  (C) Cost: false-reject rate on legitimate pairs = 0; one hash of the
      passage per verification.

Writes results/textbinding.json
Usage: python experiments/textbinding_test.py
"""
import hashlib
import hmac
import json
import os
import sys
from datetime import datetime

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))))
import ragmark as R
import ragmark_hardened as RH
from sklearn.decomposition import PCA

N_DOCS = 500
KEY = R.MASTER_KEY
SEED = 2026


def h_text(t):
    return hashlib.sha256(t.encode("utf-8")).hexdigest()[:32]


def sign_with_text(meta, text, key=R.MASTER_KEY):
    """Extend a hardened metadata blob with a signed text hash."""
    ht = h_text(text)
    msg = f"textbind|{meta['tag2']}|{ht}".encode()
    meta = dict(meta)
    meta["h_text"] = ht
    meta["tag_text"] = hmac.new(R._hmac_key(key), msg,
                                hashlib.sha256).hexdigest()
    return meta


def verify_text_binding(meta, served_text, key=R.MASTER_KEY):
    """Check the dereferenced text against the signed hash."""
    exp = hmac.new(R._hmac_key(key),
                   f"textbind|{meta['tag2']}|{meta['h_text']}".encode(),
                   hashlib.sha256).hexdigest()
    if not hmac.compare_digest(exp, meta["tag_text"]):
        return False
    return h_text(served_text) == meta["h_text"]


def main():
    os.makedirs("results", exist_ok=True)
    rng = np.random.default_rng(SEED)
    res = {"date": datetime.now().isoformat(),
           "test": "text-binding vs payload-swap"}

    print("=" * 62)
    print("Text-Binding Extension vs Payload-Swap (Sec. 8)")
    print("=" * 62)

    from sentence_transformers import SentenceTransformer
    from datasets import load_dataset
    print(f"\n[SETUP] Loading corpus ({N_DOCS} docs)...")
    ds = load_dataset("rajpurkar/squad", split="train")
    seen, texts = set(), []
    for r in ds:
        if r["context"] not in seen and len(texts) < N_DOCS:
            seen.add(r["context"]); texts.append(r["context"])
    model = SentenceTransformer("all-mpnet-base-v2")
    E = np.asarray(model.encode(texts, normalize_embeddings=True,
                                show_progress_bar=True))
    d = E.shape[1]
    pca = PCA(n_components=min(d, len(E))).fit(E)
    U, mu = pca.components_, pca.mean_
    e1_band, e0_band, e0_ppb = R.compute_bands(d)
    print(f"  d={d}, E_A={e1_band}, E_I={e0_band}, ppb={e0_ppb}")

    print("  Watermarking + text-binding...")
    wm, metas, tmetas = [], [], []
    for i in range(len(E)):
        w_raw, meta = RH.watermark_hardened(E[i], i % 8, U, mu,
                                            e1_band, e0_band, e0_ppb,
                                            doc_id=i, key=KEY)
        wm.append(w_raw); metas.append(meta)
        tmetas.append(sign_with_text(meta, texts[i], KEY))
    wm = np.asarray(wm)

    # =================================================================
    # (A) No text-binding: payload-swap passes
    # =================================================================
    print("\n[A] Payload-swap WITHOUT text-binding (base)")
    swap_pass = 0
    for i in range(500):
        # vector untouched & valid; attacker serves a DIFFERENT doc's text
        j = int(rng.integers(0, len(texts)))
        if j == i:
            j = (j + 1) % len(texts)
        v = RH.verify_hardened(wm[i], U, mu, e0_band, e0_ppb,
                               meta=metas[i], key=KEY,
                               expected_doc_id=i)["verdict"]
        # base gate certifies the vector; nothing checks the served text
        swap_pass += (v == "PASS")
    print(f"  Payload-swap PASS (vector verifies, text unchecked): "
          f"{swap_pass}/500")
    res["A_swap_pass"] = f"{swap_pass}/500"

    # =================================================================
    # (B) With text-binding: swap rejected, legit passes
    # =================================================================
    print("\n[B] Payload-swap WITH text-binding")
    swap_rej = 0
    legit_pass = 0
    for i in range(500):
        j = int(rng.integers(0, len(texts)))
        if j == i:
            j = (j + 1) % len(texts)
        # attacker serves doc j's text under doc i's (vector, metadata)
        swap_rej += (not verify_text_binding(tmetas[i], texts[j], KEY))
        # legitimate pair still verifies
        legit_pass += verify_text_binding(tmetas[i], texts[i], KEY)
    print(f"  Payload-swap rejected (h_text mismatch): {swap_rej}/500")
    print(f"  Legitimate (vector,text) pairs pass:     {legit_pass}/500")
    res["B_swap_rejected"] = f"{swap_rej}/500"
    res["B_legit_pass"] = f"{legit_pass}/500"

    # =================================================================
    # (C) Cost
    # =================================================================
    print("\n[C] Cost")
    print(f"  False rejects on legitimate pairs: {500-legit_pass}/500")
    print(f"  Overhead: one SHA-256 of the passage per verification")
    res["C_false_rejects"] = f"{500-legit_pass}/500"

    print("\n" + "=" * 62)
    print("SUMMARY")
    print(f"  without binding: payload-swap passes {swap_pass}/500")
    print(f"  with binding:    swap rejected {swap_rej}/500, "
          f"legit {legit_pass}/500")
    print("  -> the separation assumption is now OPTIONAL: co-located")
    print("     deployments bind H(text) and measure 0 false rejects.")
    print("=" * 62)
    with open("results/textbinding.json", "w") as f:
        json.dump(res, f, indent=2, default=float)
    print("Saved results/textbinding.json")


if __name__ == "__main__":
    main()
